import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CustomCursor } from "./components/CustomCursor";
import { Loader } from "./components/Loader";
import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { About } from "./components/About";
import { Services } from "./components/Services";
import { Process } from "./components/Process";
import { Portfolio } from "./components/Portfolio";
import { Stats } from "./components/Stats";
import { Testimonials } from "./components/Testimonials";
import { Contact } from "./components/Contact";
import { Footer } from "./components/Footer";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);

  return (
    <>
      {/* 1. Luxurious custom magnetic mouse cursor */}
      <CustomCursor />

      {/* 2. Global cinematic analog film noise grain overlay */}
      <div className="noise-overlay" />

      {/* 3. Infinite drawing loader screen */}
      <AnimatePresence mode="wait">
        {isLoading ? (
          <Loader key="loader" onComplete={() => setIsLoading(false)} />
        ) : (
          <motion.div
            key="content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full min-h-screen bg-[#050505] selection:bg-white selection:text-black overflow-x-hidden"
          >
            {/* Header & Fixed elements */}
            <Navbar />

            {/* Immersive Fixed Elements (Vertical Rail & Atmosphere) from Immersive UI */}
            <div className="fixed left-6 top-1/2 -translate-y-1/2 [writing-mode:vertical-rl] rotate-180 z-30 pointer-events-none hidden xl:block">
              <span className="text-[9px] uppercase tracking-[0.5em] text-white/20 font-mono">
                Est. 2026 &copy; Aureon Studios Digital Experience
              </span>
            </div>

            <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] md:w-[800px] h-[600px] md:h-[800px] bg-white/[0.03] blur-[120px] rounded-full pointer-events-none -z-0" />

            {/* Immersive sections */}
            <main className="relative z-10">
              <Hero />
              <About />
              <Services />
              <Process />
              <Portfolio />
              <Stats />
              <Testimonials />
              <Contact />
            </main>

            {/* Typography-led Footer */}
            <Footer />
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
