import React from 'react';
import { motion } from 'motion/react';
import { PRICING_PLANS, PricingPlan } from '../data';
import { Check, Sparkles, ArrowRight } from 'lucide-react';

interface PricingSectionProps {
  onBookConsultation: () => void;
}

export const PricingSection: React.FC<PricingSectionProps> = ({ onBookConsultation }) => {
  return (
    <section 
      id="pricing" 
      className="py-24 md:py-32 bg-[#050505] relative overflow-hidden"
    >
      {/* Decorative Blur Spheres */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute bottom-0 right-1/4 w-[350px] h-[350px] bg-silver/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 md:mb-24 gap-6 text-left">
          <div className="max-w-xl">
            <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Investment Plans</span>
            <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium">
              Transparent <br />
              <span className="font-serif italic text-gold">Commitment.</span>
            </h2>
          </div>
          <p className="font-sans text-xs md:text-sm text-silver max-w-sm leading-relaxed text-opacity-80">
            Select an ecosystem caliber engineered for your organizational scale. All services are governed by customized service-level covenants, keeping client capture fluid.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div 
          className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch" 
          id="pricing-grid-container"
        >
          {PRICING_PLANS.map((plan, index) => {
            return (
              <div
                key={plan.name}
                className={`relative border rounded-2xl p-8 md:p-10 flex flex-col justify-between h-full transition-all duration-500 overflow-hidden text-left group ${
                  plan.isPopular
                    ? 'border-gold/60 bg-dark-panel shadow-[0_20px_50px_rgba(212,175,55,0.08)]'
                    : 'border-white/5 bg-black hover:border-white/20'
                }`}
                id={`pricing-card-${plan.name.toLowerCase().replace(/\s+/g, '-')}`}
              >
                {/* Popular Glow Tag */}
                {plan.isPopular && (
                  <div className="absolute top-0 right-0 p-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-gold bg-gold/15 font-mono text-[8px] text-gold tracking-widest uppercase font-semibold">
                      <Sparkles className="w-2.5 h-2.5" />
                      Signature Experience
                    </span>
                  </div>
                )}

                {/* Card Top: Price and Intro */}
                <div>
                  <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-2">
                    Caliber Tier
                  </span>
                  <h3 className="font-serif text-xl md:text-2xl text-white font-medium mb-1">
                    {plan.name}
                  </h3>
                  <p className="font-sans text-[11px] text-silver text-opacity-50 leading-relaxed mb-6">
                    {plan.tagline}
                  </p>

                  {/* Pricing Tag */}
                  <div className="flex items-baseline mb-8 pb-6 border-b border-white/5">
                    <span className="font-serif text-3xl md:text-4xl font-bold text-white tracking-tight">
                      {plan.price}
                    </span>
                    <span className="font-mono text-[9px] text-silver text-opacity-40 tracking-widest uppercase ml-2">
                      / {plan.period}
                    </span>
                  </div>

                  {/* Feature Checklist */}
                  <ul className="space-y-3.5 mb-10">
                    {plan.features.map((feature, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-3">
                        <Check className="w-4 h-4 text-gold flex-shrink-0 mt-0.5" />
                        <span className="font-sans text-xs text-silver text-opacity-90 leading-normal">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card Bottom: Consultation Trigger */}
                <div>
                  <button
                    onClick={onBookConsultation}
                    className={`w-full py-3 rounded-lg text-center font-semibold text-xs tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${
                      plan.isPopular
                        ? 'bg-gold hover:bg-gold-hover text-black'
                        : 'bg-transparent border border-white/10 text-white hover:border-gold hover:text-gold hover:bg-gold/5'
                    }`}
                    id={`pricing-cta-${plan.name.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    <span>Secure Slot Engagement</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-sans text-[8px] text-silver text-opacity-35 block mt-4 text-center leading-none">
                    * Retainer parameters adjustable. Strictly illustrative pricing indices. No transaction gate present.
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
