import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { INSIGHTS, Insight } from '../data';
import { X, Clock, Calendar, User, BookOpen, ChevronRight, CornerDownRight } from 'lucide-react';

export const InsightsSection: React.FC = () => {
  const [selectedInsight, setSelectedInsight] = useState<Insight | null>(null);

  return (
    <section 
      id="insights" 
      className="py-24 md:py-32 bg-black relative overflow-hidden"
    >
      {/* Decorative Blur */}
      <div className="absolute top-0 right-1/4 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 md:mb-24 gap-6 text-left">
          <div className="max-w-xl">
            <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Our Journal</span>
            <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium">
              Intellectual <br />
              <span className="font-serif italic text-gold">Currents.</span>
            </h2>
          </div>
          <p className="font-sans text-xs md:text-sm text-silver max-w-sm leading-relaxed text-opacity-80">
            Provocative treatises on luxury strategy, digital WebGL architecture, and AI-enabled client captures. Guided by founder Parth Mehrotra and senior partners.
          </p>
        </div>

        {/* Insights Grid */}
        <div 
          className="grid grid-cols-1 md:grid-cols-2 gap-8" 
          id="insights-grid"
        >
          {INSIGHTS.map((insight) => {
            return (
              <div
                key={insight.id}
                onClick={() => setSelectedInsight(insight)}
                className="group cursor-pointer bg-dark-panel border border-white/5 rounded-2xl overflow-hidden flex flex-col md:flex-row items-stretch h-auto md:h-[260px] hover:border-gold/30 transition-all duration-500 text-left relative"
                data-cursor="explore"
                id={`insight-card-${insight.id}`}
              >
                {/* Image panel */}
                <div className="w-full md:w-5/12 h-48 md:h-auto overflow-hidden relative">
                  <img
                    src={insight.image}
                    alt={insight.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-[1200ms] ease-out object-center filter brightness-[0.75]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent to-black/30 pointer-events-none" />
                </div>

                {/* Content Panel */}
                <div className="w-full md:w-7/12 p-6 md:p-8 flex flex-col justify-between">
                  <div>
                    {/* Meta */}
                    <div className="flex items-center gap-4 mb-3 text-[10px] font-mono text-silver text-opacity-50">
                      <span className="text-gold font-semibold">{insight.category}</span>
                      <span>•</span>
                      <span>{insight.readTime}</span>
                    </div>

                    <h3 className="font-serif text-lg md:text-xl text-white font-medium group-hover:text-gold transition-colors duration-300 line-clamp-2 leading-snug">
                      {insight.title}
                    </h3>
                    <p className="font-sans text-xs text-silver mt-3 text-opacity-70 line-clamp-2 leading-relaxed">
                      {insight.summary}
                    </p>
                  </div>

                  {/* Read Link */}
                  <div className="flex items-center gap-2 mt-4 text-silver group-hover:text-gold transition-colors duration-300">
                    <span className="font-sans text-[10px] tracking-widest uppercase font-semibold">
                      Analyse Treatise
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Full Article Modal Reading Suite */}
      <AnimatePresence>
        {selectedInsight && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedInsight(null)}
              className="absolute inset-0 bg-black/95 backdrop-blur-md"
              id="insight-modal-backdrop"
            />

            {/* Reading Board */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              transition={{ type: 'spring', damping: 25, stiffness: 180 }}
              className="relative w-full max-w-3xl bg-[#0b0b0b] border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-10 flex flex-col h-[90vh] md:h-auto max-h-[700px]"
              id="insight-article-board"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedInsight(null)}
                className="absolute top-6 right-6 p-2 rounded-full border border-white/5 bg-white/5 hover:bg-white/10 hover:border-white/20 text-silver hover:text-white transition-all cursor-pointer z-20"
                aria-label="Close reading suite"
                id="close-insight-modal"
              >
                <X className="w-4 h-4" />
              </button>

              {/* Banner with category overlay */}
              <div className="h-44 w-full relative overflow-hidden bg-black flex-shrink-0">
                <img
                  src={selectedInsight.image}
                  alt={selectedInsight.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover filter brightness-[0.5] object-center"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0b] via-transparent to-transparent" />
                
                <div className="absolute bottom-6 left-8 text-left">
                  <span className="px-3 py-1 rounded-full border border-gold/30 bg-gold/15 font-mono text-[9px] text-gold tracking-widest uppercase">
                    {selectedInsight.category}
                  </span>
                </div>
              </div>

              {/* Content Reading Body */}
              <div className="p-8 md:p-10 overflow-y-auto text-left flex-grow">
                {/* Meta details */}
                <div className="flex flex-wrap items-center gap-4 text-[10px] font-mono text-silver text-opacity-50 mb-4 pb-4 border-b border-white/5">
                  <div className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-gold" />
                    <span>Author: {selectedInsight.author}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-gold" />
                    <span>Date: {selectedInsight.date}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-gold" />
                    <span>Read length: {selectedInsight.readTime}</span>
                  </div>
                </div>

                {/* Article Header */}
                <h2 className="font-serif text-2xl md:text-3xl text-white font-medium mb-6 leading-snug tracking-wide">
                  {selectedInsight.title}
                </h2>

                {/* Detailed Mock Article Content */}
                <div className="font-sans text-xs md:text-sm text-silver/90 leading-relaxed space-y-4">
                  <p className="font-serif italic text-base text-gold leading-relaxed mb-6">
                    "{selectedInsight.summary}"
                  </p>
                  
                  <div className="flex gap-2 items-start text-white mb-2">
                    <CornerDownRight className="w-4 h-4 text-gold flex-shrink-0 mt-1" />
                    <h4 className="font-serif text-base font-semibold">I. The Commoditization Threshold</h4>
                  </div>
                  <p>
                    In today's digital landscape, the volume of content generated is expanding exponentially. Under this massive deluge, standard brand guidelines, stock imagery, and generic layouts represent a terminal descent into visual noise. When everything is templated and everyone relies on generic assets, the direct result is a total destruction of customer desire.
                  </p>
                  
                  <p>
                    To stop scrolling and capture attention, luxury brands must establish what we call the <strong>Aesthetic Threshold of Uniqueness</strong>. This involves treating digital real estate not as a collection of informational grids, but as an interactive gallery. WebGL rendering, micro-interactions, custom-sculpted typography, and server-side model processing are not features—they are the modern equivalents of marble columns and velvet ropes in physical luxury boutiques.
                  </p>

                  <div className="flex gap-2 items-start text-white mt-6 mb-2">
                    <CornerDownRight className="w-4 h-4 text-gold flex-shrink-0 mt-1" />
                    <h4 className="font-serif text-base font-semibold">II. The Human Core inside AI Channels</h4>
                  </div>
                  <p>
                    AI should never be used to simulate empathy or replace genuine craft. Rather, models should be engineered server-side to absorb friction, handle routine operational alignment, and free up creative resources. A luxury brand's soul remains human, written in narrative brushstrokes that express conviction. Controlling direct digital client capture is the final command post—ensuring that every pixel, every sound, and every loading percentage represents a curated, compromises-free digital experience.
                  </p>
                </div>

                {/* Closing signature block */}
                <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gold/15 flex items-center justify-center font-serif text-gold text-xs font-bold border border-gold/30">
                      {selectedInsight.author.slice(0, 1)}
                    </div>
                    <div>
                      <span className="font-sans text-xs text-white block leading-none">{selectedInsight.author}</span>
                      <span className="font-mono text-[8px] text-silver text-opacity-40 tracking-widest uppercase">Senior Editorial Board</span>
                    </div>
                  </div>
                  <span className="font-mono text-[8px] text-silver text-opacity-30">
                    © 2026 Aureon Studios. Illustrative Editorial.
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
