import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowDown, 
  ArrowUpRight, 
  ArrowUp, 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  Linkedin, 
  Instagram, 
  Twitter, 
  Layers, 
  Sparkles, 
  Check, 
  Clock, 
  ArrowRight,
  TrendingUp,
  Award,
  Shield,
  Dribbble
} from 'lucide-react';

// Subcomponents
import { Loader } from './components/Loader';
import { Navbar } from './components/Navbar';
import { AureonLogo } from './components/AureonLogo';
import { CustomCursor } from './components/CustomCursor';
import { ThreeCanvas } from './components/ThreeCanvas';
import { ServicesSection } from './components/ServicesSection';
import { PortfolioSection } from './components/PortfolioSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { ProcessSection } from './components/ProcessSection';
import { PricingSection } from './components/PricingSection';
import { InsightsSection } from './components/InsightsSection';
import { ConsultationModal } from './components/ConsultationModal';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [is404, setIs404] = useState(false);

  useEffect(() => {
    // Detect custom sub-paths to render the official Error / 404 page
    const pathname = window.location.pathname;
    if (pathname !== '/' && pathname !== '' && pathname !== '/index.html') {
      setIs404(true);
    }
  }, []);
  
  // State for Contact Form
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    details: ''
  });
  const [contactSuccess, setContactSuccess] = useState(false);

  // Monitor Scroll for Scroll-to-Top Button
  useEffect(() => {
    const handleScrollVisibility = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScrollVisibility);
    return () => window.removeEventListener('scroll', handleScrollVisibility);
  }, []);

  // Scroll Spy Observer to Highlight Active Navbar item
  useEffect(() => {
    if (isLoading) return;

    const sections = [
      'home', 'about', 'services', 'portfolio', 
      'case-studies', 'process', 'pricing', 'insights', 'contact'
    ];

    const observers = sections.map((id) => {
      const element = document.getElementById(id);
      if (!element) return null;

      const observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              setActiveSection(id);
            }
          });
        },
        { 
          rootMargin: '-30% 0px -40% 0px', // Trigger when section occupies center window
          threshold: 0 
        }
      );

      observer.observe(element);
      return { observer, element };
    });

    return () => {
      observers.forEach((obs) => {
        if (obs) obs.observer.unobserve(obs.element);
      });
    };
  }, [isLoading]);

  // Scroll to Top action
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Newsletter Submit handler
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setIsSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
    }, 2000);
  };

  // Contact Submit handler
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setTimeout(() => {
      setContactForm({ name: '', email: '', details: '' });
      setContactSuccess(false);
    }, 3000);
  };

  if (is404) {
    return (
      <div className="bg-[#050505] text-white min-h-screen font-sans antialiased flex flex-col items-center justify-center p-6 selection:bg-gold selection:text-black relative overflow-hidden">
        {/* Custom Luxury Interactive Cursor */}
        <CustomCursor />

        {/* Ambient Atmosphere Background */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute top-1/4 left-1/4 w-[45%] h-[45%] rounded-full bg-gold opacity-[0.05] blur-[150px]" />
          <div className="absolute bottom-1/4 right-1/4 w-[40%] h-[40%] rounded-full bg-white opacity-[0.03] blur-[120px]" />
        </div>

        {/* 404 Page Card Wrapper */}
        <div className="relative z-10 flex flex-col items-center justify-center max-w-lg w-full text-center space-y-8 select-none">
          {/* Centered full-stacked official Aureon Studios Logo with metallic sweep */}
          <AureonLogo size={145} variant="full" glowing={true} />

          <div className="space-y-3">
            <span className="font-mono text-[10px] md:text-xs tracking-[0.5em] text-gold uppercase block animate-pulse">
              Error Coordinate: 404
            </span>
            <h1 className="font-serif text-3xl md:text-4xl text-white font-light tracking-tight leading-tight">
              The coordinates you seek <br />have <span className="italic font-light text-gold">dissolved.</span>
            </h1>
            <p className="font-sans text-xs md:text-sm text-white/50 max-w-md mx-auto leading-relaxed font-light">
              This space has either migrated across digital matrices or does not exist within current records. Let us align you back to base.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => { window.location.href = '/'; }}
            className="px-8 py-3.5 bg-gold hover:bg-gold-hover text-black font-bold text-xs tracking-widest uppercase rounded-full transition-all duration-300 flex items-center gap-2 cursor-pointer border border-gold"
          >
            <span>Return to Main Grid</span>
            <ArrowUpRight className="w-4.5 h-4.5" />
          </motion.button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#050505] text-white min-h-screen font-sans antialiased overflow-x-hidden selection:bg-gold selection:text-black">
      {/* Immersive Loading Screen */}
      {isLoading ? (
        <Loader onComplete={() => setIsLoading(false)} />
      ) : (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="relative min-h-screen"
        >
          {/* Custom Luxury Interactive Cursor */}
          <CustomCursor />

          {/* Background Atmosphere & Ambient Lighting */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
            <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full bg-gold opacity-[0.08] blur-[150px]" />
            <div className="absolute bottom-[-10%] right-[-5%] w-[55%] h-[55%] rounded-full bg-[#333] opacity-[0.15] blur-[120px]" />
            <div className="absolute inset-0 opacity-[0.035]" style={{ backgroundImage: "url('data:image/svg+xml,%3Csvg viewBox=\"0 0 200 200\" xmlns=\"http://www.w3.org/2000/svg\"%3E%3Cfilter id=\"noiseFilter\"%3E%3CfeTurbulence type=\"fractalNoise\" baseFrequency=\"0.65\" numOctaves=\"3\" stitchTiles=\"stitch\"/%3E%3C/filter%3E%3Crect width=\"100%25\" height=\"100%25\" filter=\"url(%23noiseFilter)\"/%3E%3C/svg%3E')" }} />
          </div>

          {/* Fixed Side Rails (Editorial Theme) */}
          <div className="fixed left-6 md:left-12 top-1/2 -translate-y-1/2 hidden xl:flex flex-col gap-24 items-center z-40 pointer-events-none select-none">
            <div className="w-[1px] h-32 bg-gradient-to-b from-transparent via-gold/50 to-transparent" />
            <div 
              className="vertical-rl text-[10px] tracking-[0.5em] text-white/30 uppercase flex gap-8 whitespace-nowrap"
              style={{ writingMode: 'vertical-rl' }}
            >
              <span>Est. 2024</span>
              <span>Mumbai • India</span>
            </div>
            <div className="w-[1px] h-32 bg-gradient-to-b from-transparent via-white/10 to-transparent" />
          </div>

          {/* Fixed Glassmorphic Header / Navigation */}
          <Navbar 
            activeSection={activeSection} 
            onBookConsultation={() => setIsConsultationOpen(true)} 
          />

          {/* MAIN EXPERIENCE CONTENT */}
          <main className="relative z-10">
            
            {/* 1. HERO SECTION */}
            <section 
              id="home" 
              className="min-h-screen flex flex-col justify-center relative pt-20 md:pt-0"
            >
              <div className="max-w-7xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center w-full relative z-10 py-12 md:py-24">
                
                {/* Left Column: Massive Editorial Headings (Lg-Span-7) */}
                <div className="lg:col-span-7 text-left flex flex-col justify-center relative">
                  <div className="mb-4">
                    <AureonLogo size={28} showText={true} variant="compact" textClassName="text-xs" />
                  </div>
                  <span className="font-mono text-[10px] md:text-xs tracking-[0.6em] text-gold uppercase block mb-6 animate-pulse">
                    Building Brands. Inspiring Growth.
                  </span>

                  <h1 className="font-serif text-5xl sm:text-7xl md:text-[92px] xl:text-[100px] leading-[0.85] font-black tracking-tighter text-white flex flex-col mb-4">
                    <span>BUILDING</span>
                    <span className="text-gold italic font-light my-1 md:my-2">BRANDS</span>
                    <span>THAT <span className="text-white/20">INSPIRE.</span></span>
                  </h1>

                  <p className="font-sans text-sm md:text-base text-white/50 mt-8 max-w-lg leading-relaxed font-light">
                    Aureon Studios partners with visionary businesses to create iconic brand identities, high-impact films, modern e-commerce systems, and intelligent server-side AI integrations. 
                  </p>

                  <div className="flex flex-wrap gap-4 mt-10">
                    <button
                      onClick={() => setIsConsultationOpen(true)}
                      className="px-8 py-3.5 bg-gradient-to-r from-gold via-[#e5c158] to-gold hover:from-[#aa820a] hover:to-[#aa820a] text-black font-semibold text-xs tracking-widest uppercase rounded-lg transition-all duration-300 shadow-lg hover:shadow-gold/15 active:scale-95 cursor-pointer flex items-center gap-2"
                      id="hero-book-btn"
                    >
                      <span>Book Consultation</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        document.getElementById('portfolio')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }}
                      className="px-8 py-3.5 bg-transparent border border-white/10 hover:border-white/30 text-white font-semibold text-xs tracking-widest uppercase rounded-lg transition-colors duration-300 active:scale-95 cursor-pointer"
                      id="hero-explore-btn"
                    >
                      Explore Craft
                    </button>
                  </div>
                </div>

                {/* Right Column: 3D Interactive Three.js Sculpture (Lg-Span-5) */}
                <div className="lg:col-span-5 h-[350px] md:h-[500px] relative flex items-center justify-center">
                  {/* Decorative concentric rings of Editorial design theme */}
                  <div className="absolute w-[120%] h-[120%] pointer-events-none hidden xl:block select-none overflow-visible">
                    <div className="absolute inset-0 rounded-full border border-gold/15 border-dashed animate-spin-slow" style={{ animation: 'spin-slow 60s linear infinite' }} />
                    <div className="absolute inset-8 rounded-full border border-white/5 animate-spin-slow" style={{ animation: 'spin-slow 30s linear reverse infinite' }} />
                  </div>

                  {/* Container for WebGL */}
                  <div className="w-full h-full relative border border-white/5 bg-[#111111]/30 rounded-3xl overflow-hidden backdrop-blur-sm shadow-[0_20px_50px_rgba(0,0,0,0.6)] z-10">
                    <ThreeCanvas />

                    {/* Miniature floating detail HUD markers (Pentagram layout style) */}
                    <div className="absolute top-5 left-5 text-left pointer-events-none">
                      <span className="font-mono text-[9px] text-gold tracking-widest uppercase">System: WebGL 3D</span>
                      <span className="font-sans text-[8px] text-silver block text-opacity-40">Status: Render Loop Live (60 FPS)</span>
                    </div>
                    <div className="absolute bottom-5 right-5 text-right pointer-events-none">
                      <span className="font-mono text-[8px] text-silver text-opacity-30 uppercase tracking-widest">Interactive Mouse Space</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Downward scrolling indicator */}
              <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center gap-2 select-none z-10">
                <span className="font-mono text-[9px] text-silver text-opacity-40 tracking-[0.3em] uppercase">Scroll to Immerse</span>
                <motion.div
                  animate={{ y: [0, 8, 0] }}
                  transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
                  className="w-8 h-8 rounded-full border border-white/10 flex items-center justify-center text-gold cursor-pointer"
                  onClick={() => {
                    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  <ArrowDown className="w-3.5 h-3.5" />
                </motion.div>
              </div>
            </section>

            {/* 2. ABOUT SECTION */}
            <section 
              id="about" 
              className="py-24 md:py-32 relative bg-black overflow-hidden border-t border-white/5"
            >
              {/* Aesthetic Gradient Spot */}
              <div className="absolute top-1/2 left-1/4 -translate-y-1/2 w-[350px] h-[350px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

              <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
                {/* Intro Block */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start text-left mb-20 md:mb-28">
                  <div className="lg:col-span-5">
                    <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Our Roots</span>
                    <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium">
                      The Luxury <br />
                      <span className="font-serif italic text-gold">Manifesto.</span>
                    </h2>
                  </div>
                  <div className="lg:col-span-7 border-l border-white/10 pl-6 md:pl-10 mt-4 md:mt-0">
                    <p className="font-serif text-lg md:text-xl text-silver italic leading-relaxed text-opacity-90">
                      "To transform ambitious businesses into unforgettable brands through creativity, strategy, technology and innovation."
                    </p>
                    <p className="font-sans text-xs md:text-sm text-silver mt-6 leading-relaxed text-opacity-70 max-w-xl">
                      Founded by <strong>Parth Mehrotra</strong>, Aureon Studios is designed for clients who refuse mediocrity. We operate at the intersection of executive commercial strategy and meticulous artistic execution, ensuring your brand commands the prestige it deserves. Our vision is clear: to become India's most respected luxury creative studio.
                    </p>
                  </div>
                </div>

                {/* Core Pillars: Mission & Vision Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left mb-20 md:mb-28" id="about-pillars">
                  {/* Mission Card */}
                  <div className="bg-[#111111]/60 border border-white/5 rounded-2xl p-8 md:p-10 relative overflow-hidden group hover:border-gold/30 transition-all duration-500">
                    <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                    <span className="font-mono text-xs text-gold/60 tracking-widest uppercase block mb-4">Core Mission</span>
                    <h3 className="font-serif text-2xl md:text-3xl text-white font-medium mb-4">Strategic Transformation</h3>
                    <p className="font-sans text-xs md:text-sm text-silver text-opacity-80 leading-relaxed">
                      To empower visionary leaders with visual assets and technological architecture that solidify their market position. We replace generic advertising models with high-discretion, micro-targeted, sensory-rich narrative ecosystems.
                    </p>
                  </div>

                  {/* Vision Card */}
                  <div className="bg-[#111111]/60 border border-white/5 rounded-2xl p-8 md:p-10 relative overflow-hidden group hover:border-gold/30 transition-all duration-500">
                    <div className="absolute inset-0 bg-gradient-to-br from-silver/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
                    <span className="font-mono text-xs text-gold/60 tracking-widest uppercase block mb-4">Core Vision</span>
                    <h3 className="font-serif text-2xl md:text-3xl text-white font-medium mb-4">Elite Craftsmanship</h3>
                    <p className="font-sans text-xs md:text-sm text-silver text-opacity-80 leading-relaxed">
                      To lead as India's premier luxury consulting enclave. We constant-iterate on WebGL interfaces, high-resolution cinematography, bespoke typography, and server-side model processing to establish uncompromising modern standards.
                    </p>
                  </div>
                </div>

                {/* Founder Philosophy Quote Banner */}
                <div className="border border-white/5 bg-dark-panel p-8 md:p-12 rounded-3xl relative overflow-hidden text-left flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="absolute inset-0 bg-gradient-to-r from-gold/5 via-transparent to-transparent pointer-events-none" />
                  
                  <div className="max-w-xl relative z-10">
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-2">Founder's Note</span>
                    <h4 className="font-serif text-2xl md:text-3xl text-white font-medium mb-4 italic">"True luxury is found in details, negative space, and absolute clarity."</h4>
                    <span className="font-sans text-xs text-silver text-opacity-70">— Parth Mehrotra, Founder & Creative Director</span>
                  </div>

                  <div className="relative z-10 flex-shrink-0">
                    {/* Minimal decorative circular crest representing India / Mumbai headquarters */}
                    <div className="w-24 h-24 rounded-full border border-gold/20 flex items-center justify-center relative animate-spin duration-[25s]">
                      <div className="absolute inset-2 rounded-full border border-dashed border-silver/10" />
                      <span className="font-serif text-gold text-lg tracking-widest uppercase">A</span>
                    </div>
                  </div>
                </div>

              </div>
            </section>

            {/* 3. SERVICES SECTION (Bento and Accordion list) */}
            <ServicesSection />

            {/* 4. PORTFOLIO SECTION (Masonry layout and Storyboard popups) */}
            <PortfolioSection />

            {/* 5. CASE STUDIES SECTION (Immersive graphs and storytelling) */}
            <CaseStudiesSection />

            {/* 6. WHY CHOOSE US (Bento-Grid containing interactive 3D simulated vector visualizers) */}
            <section className="py-24 md:py-32 bg-black relative overflow-hidden border-t border-white/5">
              <div className="absolute top-1/2 left-0 -translate-y-1/2 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

              <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
                {/* Section Header */}
                <div className="max-w-xl text-left mb-16 md:mb-24">
                  <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Our Core Caliber</span>
                  <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium">
                    The Aureon <br />
                    <span className="font-serif italic text-gold">Advantage.</span>
                  </h2>
                </div>

                {/* Bento Grid layout representing our unique metrics (No standard icons, using geometric 3D shapes) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left" id="why-choose-us-grid">
                  {/* Item 1: Bespoke Visual Architecture */}
                  <div className="bg-[#111111]/70 border border-white/5 p-8 md:p-10 rounded-2xl flex flex-col justify-between h-[380px] group hover:border-gold/40 transition-all duration-500 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-transparent pointer-events-none" />
                    
                    {/* Interactive Animated Geometric Crest */}
                    <div className="w-24 h-24 mx-auto mb-6 flex items-center justify-center relative">
                      {/* Nested rotating gold wireframe borders */}
                      <div className="absolute inset-0 rounded-xl border border-gold/30 animate-spin duration-[10s]" />
                      <div className="absolute inset-3 rounded-full border-2 border-double border-white/10 animate-spin duration-[6s] reverse" />
                      <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#AA820A] to-[#F5E6A3] animate-pulse" />
                    </div>

                    <div>
                      <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-2">01 · Aesthetic Sovereign</span>
                      <h3 className="font-serif text-xl md:text-2xl text-white font-medium mb-3">Bespoke Visual Architecture</h3>
                      <p className="font-sans text-xs text-silver text-opacity-70 leading-relaxed">
                        We reject template layouts. We curate custom editorial font hierarchies, metallic gradient schemas, and custom SVG crest matrices that establish instant command positioning.
                      </p>
                    </div>
                  </div>

                  {/* Item 2: Strategic Performance Analytics */}
                  <div className="bg-[#111111]/70 border border-white/5 p-8 md:p-10 rounded-2xl flex flex-col justify-between h-[380px] group hover:border-gold/40 transition-all duration-500 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-silver/5 via-transparent to-transparent pointer-events-none" />

                    {/* Interactive Animated Geometric Pyramid */}
                    <div className="w-24 h-24 mx-auto mb-6 flex items-center justify-center relative">
                      <div className="absolute inset-0 flex items-center justify-center animate-pulse">
                        {/* Custom visual wireframe node bar graph */}
                        <svg viewBox="0 0 100 100" className="w-16 h-16 opacity-60">
                          <rect x="15" y="45" width="10" height="40" fill="#C0C0C0" className="animate-pulse" style={{ animationDelay: '0.1s' }} />
                          <rect x="35" y="25" width="10" height="60" fill="#D4AF37" className="animate-pulse" style={{ animationDelay: '0.3s' }} />
                          <rect x="55" y="10" width="10" height="75" fill="#FFFFFF" className="animate-pulse" style={{ animationDelay: '0.5s' }} />
                          <rect x="75" y="30" width="10" height="55" fill="#8E8E93" className="animate-pulse" style={{ animationDelay: '0.7s' }} />
                        </svg>
                      </div>
                    </div>

                    <div>
                      <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-2">02 · Numeric Proofs</span>
                      <h3 className="font-serif text-xl md:text-2xl text-white font-medium mb-3">Quantitative Precision</h3>
                      <p className="font-sans text-xs text-silver text-opacity-70 leading-relaxed">
                        Every design choice is validated. We deploy analytics, clickstream maps, and custom user conversion metrics to guarantee your luxury positioning translates to high revenue yield.
                      </p>
                    </div>
                  </div>

                  {/* Item 3: Autonomous System Integrations */}
                  <div className="bg-[#111111]/70 border border-white/5 p-8 md:p-10 rounded-2xl flex flex-col justify-between h-[380px] group hover:border-gold/40 transition-all duration-500 relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-transparent pointer-events-none" />

                    {/* Interactive Rotating Glass Spheres */}
                    <div className="w-24 h-24 mx-auto mb-6 flex items-center justify-center relative">
                      <div className="absolute inset-0 rounded-full border border-dashed border-white/10 animate-spin duration-[15s]" />
                      <div className="w-12 h-12 rounded-full border border-gold/40 flex items-center justify-center animate-pulse">
                        <div className="w-6 h-6 rounded-full bg-gold/20 flex items-center justify-center font-mono text-[9px] text-gold">AI</div>
                      </div>
                    </div>

                    <div>
                      <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-2">03 · Intelligent Channels</span>
                      <h3 className="font-serif text-xl md:text-2xl text-white font-medium mb-3">Autonomous System Integration</h3>
                      <p className="font-sans text-xs text-silver text-opacity-70 leading-relaxed">
                        We integrate server-side Gemini AI models, bespoke conversational pipelines, and secure cloud storage CRM triggers to automate client capturing and eliminate operations friction.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* 7. PROCESS SECTION (Horizontal scroll layout) */}
            <ProcessSection />

            {/* 8. STATISTICS SECTION */}
            <section className="py-20 md:py-28 bg-[#0b0b0b] relative overflow-hidden border-t border-b border-white/5">
              <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12" id="studio-metrics-panel">
                  {/* Stat 1 */}
                  <div className="text-center md:text-left flex flex-col justify-between p-6 bg-black/40 border border-white/5 rounded-2xl">
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase mb-2 block">Projects Released</span>
                    <span className="font-serif text-4xl md:text-6xl text-white font-bold tracking-tight">25+</span>
                    <p className="font-sans text-[10px] text-silver text-opacity-50 mt-4 leading-normal">
                      * Illustrative index representing total historical design configurations.
                    </p>
                  </div>

                  {/* Stat 2 */}
                  <div className="text-center md:text-left flex flex-col justify-between p-6 bg-black/40 border border-white/5 rounded-2xl">
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase mb-2 block">Retained Clients</span>
                    <span className="font-serif text-4xl md:text-6xl text-white font-bold tracking-tight">12</span>
                    <p className="font-sans text-[10px] text-silver text-opacity-50 mt-4 leading-normal">
                      * Illustrative tracker of active collaborative design partnerships.
                    </p>
                  </div>

                  {/* Stat 3 */}
                  <div className="text-center md:text-left flex flex-col justify-between p-6 bg-black/40 border border-white/5 rounded-2xl">
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase mb-2 block">Client Satisfaction</span>
                    <span className="font-serif text-4xl md:text-6xl text-white font-bold tracking-tight">97%</span>
                    <p className="font-sans text-[10px] text-silver text-opacity-50 mt-4 leading-normal">
                      * Proportional quality score derived from feedback parameters.
                    </p>
                  </div>

                  {/* Stat 4 */}
                  <div className="text-center md:text-left flex flex-col justify-between p-6 bg-black/40 border border-white/5 rounded-2xl">
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase mb-2 block">Average Growth Yield</span>
                    <span className="font-serif text-4xl md:text-6xl text-white font-bold tracking-tight">3X</span>
                    <p className="font-sans text-[10px] text-silver text-opacity-50 mt-4 leading-normal">
                      * Average revenue acceleration index for active clients.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* 9. TESTIMONIALS (Tactile infinite marquee sliders) */}
            <section className="py-24 md:py-32 bg-[#050505] relative overflow-hidden">
              <div className="absolute top-1/2 right-1/4 -translate-y-1/2 w-[350px] h-[350px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

              <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
                {/* Section Header */}
                <div className="max-w-xl text-left mb-16 md:mb-20">
                  <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Connoisseur Feedback</span>
                  <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium">
                    Prestige <br />
                    <span className="font-serif italic text-gold">Appreciations.</span>
                  </h2>
                </div>

                {/* Infinite Moving Slider (using marquee simulation on flex row with pause-on-hover) */}
                <div className="relative w-full overflow-hidden py-4" id="testimonials-scroller">
                  <div className="flex gap-6 animate-marquee hover:[animation-play-state:paused] w-max whitespace-nowrap">
                    {/* Set 1 */}
                    {[...Array(2)].map((_, loopIdx) => (
                      <React.Fragment key={loopIdx}>
                        {/* Slide 1 */}
                        <div className="inline-block w-[320px] md:w-[450px] bg-dark-panel border border-white/5 p-8 rounded-2xl whitespace-normal text-left">
                          <p className="font-serif italic text-sm md:text-base text-silver leading-relaxed text-opacity-90 mb-6">
                            "Aureon Studios doesn't build basic websites. They design absolute works of digital art. Our online conversion rates skyrocketed by 34% within the first two months of launching."
                          </p>
                          <div className="flex items-center justify-between border-t border-white/5 pt-4">
                            <div>
                              <span className="font-serif text-xs text-white block">Elena Laurent</span>
                              <span className="font-mono text-[8px] text-silver text-opacity-40 tracking-widest uppercase">Global Marketing · Maison d'Or</span>
                            </div>
                            <span className="font-serif text-gold text-xs">★★★★★</span>
                          </div>
                        </div>

                        {/* Slide 2 */}
                        <div className="inline-block w-[320px] md:w-[450px] bg-dark-panel border border-white/5 p-8 rounded-2xl whitespace-normal text-left">
                          <p className="font-serif italic text-sm md:text-base text-silver leading-relaxed text-opacity-90 mb-6">
                            "Parth Mehrotra and his team at Aureon Studios are strategic geniuses. They completely reimagined our brand positioning. We were booked out three seasons in advance."
                          </p>
                          <div className="flex items-center justify-between border-t border-white/5 pt-4">
                            <div>
                              <span className="font-serif text-xs text-white block">Aditya Roy</span>
                              <span className="font-mono text-[8px] text-silver text-opacity-40 tracking-widest uppercase">Chief Operating Officer · Zenith Resorts</span>
                            </div>
                            <span className="font-serif text-gold text-xs">★★★★★</span>
                          </div>
                        </div>

                        {/* Slide 3 */}
                        <div className="inline-block w-[320px] md:w-[450px] bg-dark-panel border border-white/5 p-8 rounded-2xl whitespace-normal text-left">
                          <p className="font-serif italic text-sm md:text-base text-silver leading-relaxed text-opacity-90 mb-6">
                            "The visual precision and technical brilliance they brought to our product reveal was astonishing. The interactive 3D configurator they built became the focal point of our GT launch."
                          </p>
                          <div className="flex items-center justify-between border-t border-white/5 pt-4">
                            <div>
                              <span className="font-serif text-xs text-white block">Marcus Vance</span>
                              <span className="font-mono text-[8px] text-silver text-opacity-40 tracking-widest uppercase">VP of Product Strategy · Pegasus Motors</span>
                            </div>
                            <span className="font-serif text-gold text-xs">★★★★★</span>
                          </div>
                        </div>

                        {/* Slide 4 */}
                        <div className="inline-block w-[320px] md:w-[450px] bg-dark-panel border border-white/5 p-8 rounded-2xl whitespace-normal text-left">
                          <p className="font-serif italic text-sm md:text-base text-silver leading-relaxed text-opacity-90 mb-6">
                            "Every single interaction with Aureon feels premium. Their work looks expensive because it is executed with flawless craft. They helped us reach super-prime heights."
                          </p>
                          <div className="flex items-center justify-between border-t border-white/5 pt-4">
                            <div>
                              <span className="font-serif text-xs text-white block">Rohan Singhal</span>
                              <span className="font-mono text-[8px] text-silver text-opacity-40 tracking-widest uppercase">Managing Director · Vantage Heights</span>
                            </div>
                            <span className="font-serif text-gold text-xs">★★★★★</span>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                </div>

                <span className="font-sans text-[9px] text-silver text-opacity-30 block mt-8 text-center leading-none">
                  * All testimonials displayed are sample feedback records for illustrative case presentation.
                </span>
              </div>
            </section>

            {/* 10. PRICING SECTION (Cards and Features) */}
            <PricingSection onBookConsultation={() => setIsConsultationOpen(true)} />

            {/* 11. INSIGHTS SECTION (Journal Treatises) */}
            <InsightsSection />

            {/* 12. CONTACT SECTION (Interactive Form, Large coordinates, Vector Map layout) */}
            <section 
              id="contact" 
              className="py-24 md:py-32 bg-black relative overflow-hidden border-t border-white/5"
            >
              <div className="absolute top-0 left-1/4 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[140px] pointer-events-none" />

              <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
                  
                  {/* Left: Contact Briefing Form (Lg-Span-6) */}
                  <div className="lg:col-span-6 text-left flex flex-col justify-between">
                    <div>
                      <div className="mb-5">
                        <AureonLogo size={28} showText={true} variant="compact" textClassName="text-xs" />
                      </div>
                      <span className="font-mono text-[10px] tracking-[0.3em] text-gold uppercase block mb-3">Initiate Channels</span>
                      <h2 className="font-serif text-4xl md:text-6xl text-white tracking-tight leading-none font-medium mb-6">
                        Secure <br />
                        <span className="font-serif italic text-gold">Alignments.</span>
                      </h2>
                      <p className="font-sans text-xs md:text-sm text-silver text-opacity-70 leading-relaxed mb-8 max-w-md">
                        We accept a highly limited batch of collaborative slots quarterly. Submit a quick directive brief, or establish direct telephone mapping.
                      </p>
                    </div>

                    {/* Interactive Form */}
                    <div className="bg-dark-panel/60 border border-white/5 p-6 md:p-8 rounded-2xl relative">
                      <AnimatePresence mode="wait">
                        {!contactSuccess ? (
                          <form onSubmit={handleContactSubmit} className="space-y-4">
                            <div className="flex flex-col gap-1.5">
                              <label className="font-sans text-[10px] tracking-wider text-silver text-opacity-80 uppercase">Name *</label>
                              <input
                                type="text"
                                required
                                value={contactForm.name}
                                onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                                placeholder="Vikram Malhotra"
                                className="w-full bg-black border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-sans placeholder-white/20"
                              />
                            </div>
                            <div className="flex flex-col gap-1.5">
                              <label className="font-sans text-[10px] tracking-wider text-silver text-opacity-80 uppercase">Email *</label>
                              <input
                                type="email"
                                required
                                value={contactForm.email}
                                onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                                placeholder="vikram@vancorp.in"
                                className="w-full bg-black border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-sans placeholder-white/20"
                              />
                            </div>
                            <div className="flex flex-col gap-1.5">
                              <label className="font-sans text-[10px] tracking-wider text-silver text-opacity-80 uppercase">Vision Scope</label>
                              <textarea
                                rows={3}
                                value={contactForm.details}
                                onChange={(e) => setContactForm({ ...contactForm, details: e.target.value })}
                                placeholder="Core goals, timelines, and budget frameworks..."
                                className="w-full bg-black border border-white/10 rounded-lg px-4 py-2.5 text-xs text-white focus:outline-none focus:border-gold transition-colors font-sans resize-none placeholder-white/20"
                              />
                            </div>
                            <button
                              type="submit"
                              className="w-full py-3 bg-gold hover:bg-gold-hover text-black font-semibold text-xs tracking-widest uppercase rounded-lg transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer mt-2"
                              id="contact-form-submit-btn"
                            >
                              <span>Submit Directive</span>
                              <Send className="w-3.5 h-3.5" />
                            </button>
                          </form>
                        ) : (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="text-center py-8"
                          >
                            <div className="w-12 h-12 bg-gold/10 border border-gold/30 rounded-full flex items-center justify-center mx-auto mb-4">
                              <Check className="w-6 h-6 text-gold" />
                            </div>
                            <h3 className="font-serif text-xl text-white mb-2">Message Encrypted</h3>
                            <p className="font-sans text-xs text-silver text-opacity-70 max-w-xs mx-auto">
                              Thank you, {contactForm.name}. Your quick brief has been processed. Our partner assistant will verify coordinates shortly.
                            </p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>

                  {/* Right: Studio Coordinate Details & Vector Map of India (Lg-Span-6) */}
                  <div className="lg:col-span-6 bg-dark-panel border border-white/10 p-8 md:p-12 rounded-2xl flex flex-col justify-between relative overflow-hidden text-left">
                    <div className="absolute inset-0 bg-gradient-to-br from-gold/5 via-transparent to-transparent pointer-events-none" />

                    <div>
                      <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-4">Studio Location Base</span>
                      
                      {/* Interactive Vector Grid representing India/Mumbai Coordinate Grid Map */}
                      <div className="w-full h-[220px] bg-black/40 rounded-xl border border-white/5 p-4 mb-8 flex items-center justify-center relative">
                        {/* Grid matrix overlay */}
                        <div className="absolute inset-0 bg-[linear-gradient(to_right,#222_1px,transparent_1px),linear-gradient(to_bottom,#222_1px,transparent_1px)] bg-[size:1rem_1rem] opacity-30" />
                        
                        {/* Abstract Coordinate Mapping lines */}
                        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10 max-w-[200px]">
                          {/* India Map stylized wireframe vector */}
                          <path
                            d="M 50 10 L 58 18 L 52 30 L 62 42 L 58 55 L 68 62 L 60 70 L 52 88 L 48 88 L 45 78 L 38 65 L 35 52 L 40 40 L 33 28 L 42 18 Z"
                            fill="none"
                            stroke="rgba(255,255,255,0.12)"
                            strokeWidth="1"
                          />
                          {/* Golden radiating marker for Mumbai */}
                          <g transform="translate(38, 56)">
                            <circle r="6" fill="#D4AF37" opacity="0.25" className="animate-ping duration-[3000ms]" />
                            <circle r="3" fill="#D4AF37" filter="url(#glow)" />
                          </g>
                          {/* Secondary markers (Delhi, Bengaluru) */}
                          <circle cx="48" cy="28" r="1.5" fill="#C0C0C0" opacity="0.6" />
                          <circle cx="44" cy="74" r="1.5" fill="#C0C0C0" opacity="0.6" />
                          
                          {/* Text indicators */}
                          <text x="43" y="58" fill="#D4AF37" fontSize="5" fontFamily="monospace" letterSpacing="0.5">MUMBAI</text>
                          <text x="51" y="29" fill="#999" fontSize="3" fontFamily="monospace">Delhi</text>
                          <text x="47" y="75" fill="#999" fontSize="3" fontFamily="monospace">Blr</text>
                        </svg>

                        <div className="absolute bottom-3 left-4 text-left pointer-events-none">
                          <span className="font-mono text-[8px] text-silver text-opacity-30 uppercase block leading-none">Mapping Anchor: Mumbai Hub</span>
                          <span className="font-mono text-[8px] text-gold/50 block mt-0.5 leading-none">18.97° N, 72.82° E</span>
                        </div>
                      </div>

                      {/* Coordinates Copy */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-3 text-silver">
                          <Mail className="w-4 h-4 text-gold flex-shrink-0" />
                          <span className="font-sans text-xs tracking-wider text-opacity-90">inquiries@aureon.studio</span>
                        </div>
                        <div className="flex items-center gap-3 text-silver">
                          <Phone className="w-4 h-4 text-gold flex-shrink-0" />
                          <span className="font-sans text-xs tracking-wider text-opacity-90">+91 91100 XXXXX</span>
                        </div>
                        <div className="flex items-center gap-3 text-silver">
                          <MapPin className="w-4 h-4 text-gold flex-shrink-0" />
                          <span className="font-sans text-xs tracking-wider text-opacity-90">Colaba Enclave, Mumbai, MH 400005, India</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 pt-6 border-t border-white/5 text-left">
                      <span className="font-mono text-[8px] text-silver text-opacity-35 uppercase block">Operational Calendar</span>
                      <span className="font-sans text-xs text-white font-medium block mt-1">Monday — Friday, 10:00 — 19:00 IST</span>
                    </div>

                  </div>
                </div>
              </div>
            </section>

          </main>

          {/* 13. IMMERSIVE HIGH-TYPO FOOTER */}
          <footer className="bg-[#050505] border-t border-white/5 py-16 md:py-24 relative overflow-hidden select-none">
            <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
              
              {/* Top Row: Newsletter and Links */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pb-16 border-b border-white/5 text-left">
                {/* Brand description column (Lg-Span-4) */}
                <div className="lg:col-span-4 flex flex-col justify-between">
                  <div>
                    <div className="mb-5">
                      <AureonLogo size={32} showText={true} variant="compact" textClassName="text-base" />
                    </div>
                    <p className="font-sans text-xs text-silver text-opacity-60 leading-relaxed max-w-sm">
                      India's premium creative consulting enclave. Architecting visual desire, digital WebGL ecosystems, and Gemini-enabled captures for visionary brands.
                    </p>
                  </div>

                  {/* Social media connections */}
                  <div className="flex items-center gap-4 mt-8">
                    <a href="#twitter" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-silver hover:text-gold hover:border-gold/30 transition-all cursor-pointer">
                      <Twitter className="w-4 h-4" />
                    </a>
                    <a href="#instagram" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-silver hover:text-gold hover:border-gold/30 transition-all cursor-pointer">
                      <Instagram className="w-4 h-4" />
                    </a>
                    <a href="#linkedin" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-silver hover:text-gold hover:border-gold/30 transition-all cursor-pointer">
                      <Linkedin className="w-4 h-4" />
                    </a>
                    <a href="#dribbble" className="w-9 h-9 rounded-full border border-white/10 flex items-center justify-center text-silver hover:text-gold hover:border-gold/30 transition-all cursor-pointer">
                      <Dribbble className="w-4 h-4" />
                    </a>
                  </div>
                </div>

                {/* Index directory connections (Lg-Span-4) */}
                <div className="lg:col-span-4 grid grid-cols-2 gap-4 pl-0 lg:pl-12">
                  <div>
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-4">Directory</span>
                    <ul className="space-y-2.5 text-xs">
                      <li><a href="#home" className="text-silver hover:text-white transition-colors">Return Home</a></li>
                      <li><a href="#about" className="text-silver hover:text-white transition-colors">Our Roots</a></li>
                      <li><a href="#services" className="text-silver hover:text-white transition-colors">Our Services</a></li>
                      <li><a href="#portfolio" className="text-silver hover:text-white transition-colors">Elite Portfolio</a></li>
                    </ul>
                  </div>
                  <div>
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-4">Integrity</span>
                    <ul className="space-y-2.5 text-xs">
                      <li><a href="#case-studies" className="text-silver hover:text-white transition-colors">Case Narratives</a></li>
                      <li><a href="#process" className="text-silver hover:text-white transition-colors">The Protocol</a></li>
                      <li><a href="#pricing" className="text-silver hover:text-white transition-colors">Investment</a></li>
                      <li><a href="#insights" className="text-silver hover:text-white transition-colors">The Journal</a></li>
                    </ul>
                  </div>
                </div>

                {/* Newsletter Capturing Block (Lg-Span-4) */}
                <div className="lg:col-span-4 flex flex-col justify-between">
                  <div>
                    <span className="font-mono text-[9px] text-gold tracking-widest uppercase block mb-4">Strategic Updates</span>
                    <p className="font-sans text-xs text-silver text-opacity-60 leading-relaxed mb-4">
                      Subscribe to receive private journal treatises written by founder Parth Mehrotra directly to your cabinet inbox.
                    </p>
                  </div>

                  <form onSubmit={handleNewsletterSubmit} className="relative mt-4">
                    <input
                      type="email"
                      required
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                      placeholder="cabinet@executive.com"
                      className="w-full bg-black border border-white/10 rounded-lg px-4 py-3 text-xs text-white focus:outline-none focus:border-gold transition-colors font-sans placeholder-white/20 pr-12"
                    />
                    <button
                      type="submit"
                      disabled={isSubscribed}
                      className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-gold hover:bg-gold-hover text-black rounded transition-all cursor-pointer"
                      id="newsletter-subscribe-btn"
                    >
                      {isSubscribed ? <Check className="w-3.5 h-3.5" /> : <ArrowRight className="w-3.5 h-3.5" />}
                    </button>
                  </form>
                  {isSubscribed && (
                    <span className="font-sans text-[9px] text-gold block mt-2 text-left">
                      Secure dispatch formed. Welcome to the enclave.
                    </span>
                  )}
                </div>
              </div>

              {/* Huge Outline Brand Typography Bottom */}
              <div className="py-12 md:py-16 text-center overflow-hidden border-b border-white/5 relative">
                <h2 className="font-serif text-[12vw] font-bold text-transparent tracking-widest leading-none select-none uppercase" style={{ WebkitTextStroke: '1px rgba(255, 255, 255, 0.05)' }}>
                  Aureon
                </h2>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <span className="font-mono text-[9px] md:text-xs text-gold tracking-[0.6em] uppercase mt-2">BUILDING BRANDS. INSPIRING GROWTH.</span>
                </div>
              </div>

              {/* Bottom Copyright details Row */}
              <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-sans text-silver text-opacity-40">
                <span>© 2026 Aureon Studios Private Limited. All Rights Reserved.</span>
                <div className="flex gap-6">
                  <span>Founder: Parth Mehrotra</span>
                  <span>Made in Mumbai, India</span>
                </div>
              </div>

            </div>
          </footer>

          {/* Floating Actions Overlay (Scroll-to-top) */}
          <AnimatePresence>
            {showScrollTop && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                onClick={scrollToTop}
                className="fixed bottom-6 right-6 w-11 h-11 rounded-full bg-gold hover:bg-gold-hover text-black flex items-center justify-center shadow-lg hover:shadow-gold/25 transition-all cursor-pointer z-40 active:scale-90 border border-gold"
                aria-label="Scroll to top"
                data-cursor="pointer"
                id="scroll-to-top-btn"
              >
                <AureonLogo size={22} variant="monogram" glowing={false} />
              </motion.button>
            )}
          </AnimatePresence>

          {/* Consultation Briefing intake slide-over/modal */}
          <ConsultationModal 
            isOpen={isConsultationOpen} 
            onClose={() => setIsConsultationOpen(false)} 
          />

        </motion.div>
      )}
    </div>
  );
}
